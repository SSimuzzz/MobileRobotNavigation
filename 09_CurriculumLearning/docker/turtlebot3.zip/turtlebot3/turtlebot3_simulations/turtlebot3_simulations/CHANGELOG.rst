^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_simulations
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.7 (2017-08-16)
-----------
* renamed missed the install rule (worlds -> models)
* Contributors: Darby Lim, Tully Foote

0.1.6 (2017-08-14)
-----------
* modified folder name and model path
* updated rviz and add static tf publisher for depth camera
* Contributors: Darby Lim

0.1.5 (2017-06-09)
-----------
* modified make files for dependencies
* updated turtlebot3 sim
* updated world config
* Contributors: Darby Lim

0.1.4 (2017-05-23)
-----------
* added as new meta-packages and version update (0.1.4)
* Contributors: Darby Lim, Pyo
